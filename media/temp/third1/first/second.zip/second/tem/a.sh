touch third.txt
echo "random2" > third.txt
